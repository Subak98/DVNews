"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const sp_1 = require("@pnp/sp");
const graph_1 = require("@pnp/graph");
require("@pnp/graph/groups");
require("@pnp/graph/members");
const pnpjsConfig_1 = require("./pnpjsConfig");
const sp_http_1 = require("@microsoft/sp-http");
const moment_1 = tslib_1.__importDefault(require("moment"));
const clientside_pages_1 = require("@pnp/sp/clientside-pages");
class SharepointServiceProvider {
    //   private _webPartContext: BaseWebPartContext;
    //   private _webAbsoluteUrl: string;
    constructor(_context) {
        this._cachedGraphGroups = null;
        this._webPartContext = _context;
        this._webAbsoluteUrl = _context.pageContext.web.absoluteUrl;
        this.sp = (0, pnpjsConfig_1.getSP)(_context);
    }
    getDepartmentFieldOptions(sites) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            const siteUrl = `${sites[0].url}`;
            const subweb = (0, sp_1.spfi)(siteUrl).using((0, sp_1.SPFx)(this._webPartContext));
            const field = yield subweb.web.lists
                .getByTitle("Site Pages")
                .fields.getByTitle("Department")();
            const choices = field.Choices || [];
            return [...choices];
        });
    }
    // public async getNewsPost(
    //   sites: IPropertyFieldSite[],
    //   top: number = 200,
    //   skip: number = 0,
    // ): Promise<IFeaturedNewsList[]> {
    //   // console.log(sites);
    //   const siteUrl = `${sites[0].url}`;
    //   const subweb = spfi(siteUrl).using(SPFx(this._webPartContext));
    //   const filterNews =
    //     "PromotedState eq 2 and (Department ne null and Department ne '')";
    //   const list = subweb.web.lists.getByTitle("Site Pages");
    //   const getitems = await list.items
    //     .filter(filterNews)
    //     .select(
    //       "*",
    //       "Title",
    //       "Department",
    //       "ShowNewsinHome",
    //       "Modified",
    //       "BannerImageUrl",
    //       "Description",
    //       "FileRef",
    //       "FileDirRef",
    //       "Author/ID",
    //       "Author/Title",
    //       "Author/EMail",
    //     )
    //     .expand("Author")
    //     .orderBy("Modified", false)
    //     .skip(skip)
    //     .top(top)();
    //   console.log("getitems", getitems);
    //   // Sort by Modified date (newest first)
    //   const orderedNews = getitems.sort((a: any, b: any) => {
    //     return new Date(b.Modified).getTime() - new Date(a.Modified).getTime();
    //   });
    //   const bannerUrl = `https://media.akamai.odsp.cdn.office.net/southindia1-mediap.svc.ms/transform/thumbnail?provider=url&inputFormat=png&docid=https://media.akamai.odsp.cdn.office.net/${window.location.host}/_layouts/15/images/sitepagethumbnail.png&w=200`;
    //   const graph = graphfi().using(graphSPFx(this._webPartContext as any));
    //   const currentUserEmail =
    //     this._webPartContext.pageContext.user.email?.toLowerCase();
    //   const groups: any =
    //     this._cachedGraphGroups ||
    //     (await graph.groups.select("displayName", "id")());
    //   this._cachedGraphGroups = groups;
    //   const _items: IFeaturedNewsList[] = [];
    //   const filteredItems: IFeaturedNewsList[] = [];
    //   const groupAccessCache = new Map<string, boolean>();
    //   for (let i = 0; i < orderedNews.length; i++) {
    //     const item = orderedNews[i];
    //     const siteUrl = item._originSiteUrl;
    //     const departmentArray = Array.isArray(item.Department)
    //       ? item.Department
    //       : item.Department && typeof item.Department === "string"
    //         ? (item.Department as string)
    //             .split(",")
    //             .map((dept: string) => dept.trim())
    //             .filter(Boolean)
    //         : [];
    //     const uniqueDepartments = Array.from(new Set(departmentArray));
    //     const isDepartmentEmpty = uniqueDepartments.length === 0;
    //     let userHasAccess = isDepartmentEmpty;
    //     if (!isDepartmentEmpty) {
    //       for (const departmentName of uniqueDepartments) {
    //         const targetGroup: any = groups.find(
    //           (g: any) => g.displayName === departmentName,
    //         );
    //         if (!targetGroup) {
    //           continue;
    //         }
    //         if (groupAccessCache.has(targetGroup.id)) {
    //           if (groupAccessCache.get(targetGroup.id)) {
    //             userHasAccess = true;
    //             break;
    //           }
    //           continue;
    //         }
    //         const [groupMembers, groupOwners] = await Promise.all([
    //           graph.groups.getById(targetGroup.id).members(),
    //           graph.groups.getById(targetGroup.id).owners(),
    //         ]);
    //         const isMember = groupMembers.some(
    //           (member: any) =>
    //             member.mail?.toLowerCase() === currentUserEmail ||
    //             member.userPrincipalName?.toLowerCase() === currentUserEmail,
    //         );
    //         const isOwner = groupOwners.some(
    //           (owner: any) =>
    //             owner.mail?.toLowerCase() === currentUserEmail ||
    //             owner.userPrincipalName?.toLowerCase() === currentUserEmail,
    //         );
    //         const hasAccess = isMember || isOwner;
    //         groupAccessCache.set(targetGroup.id, hasAccess);
    //         if (hasAccess) {
    //           userHasAccess = true;
    //           break;
    //         }
    //       }
    //     }
    //     const linkUrl = item.FileRef;
    //     const imageJSON = item.Image && JSON.parse(item.Image);
    //     const relativeImage = imageJSON?.serverRelativeUrl;
    //     const customUrl =
    //       imageJSON &&
    //       siteUrl +
    //         "/Lists/SiteAssets/Attachments/" +
    //         item.Id +
    //         "/" +
    //         imageJSON?.fileName;
    //     const customPhoto = decodeURI(relativeImage) ?? customUrl;
    //     const lst: IFeaturedNewsList = {
    //       Title: item.Title || item.FileRef?.split("/SitePages/")[1],
    //       date: moment(item.Created).format("MMMM DD, yyyy"),
    //       Created: moment(item.Created).format(),
    //       Author: item.Author,
    //       Department: item.Department || "",
    //       ShowNewsinHome: item.ShowNewsinHome,
    //       AuthorByLine: item.Author ? item.Author : "",
    //       Image:
    //         customPhoto &&
    //         customPhoto !== undefined &&
    //         customPhoto !== "undefined"
    //           ? customPhoto
    //           : (item.BannerImageUrl?.Url ?? bannerUrl),
    //       Description: item.Description,
    //       Link: linkUrl || "",
    //     };
    //     _items.push(lst);
    //     if (userHasAccess) {
    //       filteredItems.push(lst);
    //     }
    //   }
    //   console.log(filteredItems);
    //   return filteredItems.length > 0 ? filteredItems : _items;
    // }
    getNewsPost(sites_1) {
        return tslib_1.__awaiter(this, arguments, void 0, function* (sites, top = 200, skip = 0) {
            const siteUrl = `${sites[0].url}`;
            const subweb = (0, sp_1.spfi)(siteUrl).using((0, sp_1.SPFx)(this._webPartContext));
            const filterNews = "PromotedState eq 2";
            const list = subweb.web.lists.getByTitle("Site Pages");
            const siteTitle = yield this.sp.web.select("Title")();
            const getitems = yield list.items
                .filter(filterNews)
                .select("*", "Title", "Department", "ShowNewsinHome", "Modified", "BannerImageUrl", "Description", "FileRef", "FileDirRef", "Author/ID", "Author/Title", "Author/EMail")
                .expand("Author")
                .orderBy("Modified", false)
                .skip(skip)
                .top(top)();
            console.log(getitems);
            const normalizedSiteTitle = ((siteTitle === null || siteTitle === void 0 ? void 0 : siteTitle.Title) || "").trim().toLowerCase();
            console.log(normalizedSiteTitle);
            const filteredItems = getitems.filter((item) => {
                const departmentValues = Array.isArray(item.Department)
                    ? item.Department
                    : typeof item.Department === "string"
                        ? item.Department.split(",").map((dept) => dept.trim())
                        : [];
                const normalizedDepartments = departmentValues
                    .filter(Boolean)
                    .map((dept) => dept.toLowerCase());
                return (normalizedDepartments.includes("all") ||
                    normalizedDepartments.includes(normalizedSiteTitle));
            });
            console.log(filteredItems);
            return filteredItems.map((item) => {
                var _a, _b, _c, _d;
                const itemSiteUrl = item._originSiteUrl;
                const imageJSON = item.Image && JSON.parse(item.Image);
                const relativeImage = imageJSON === null || imageJSON === void 0 ? void 0 : imageJSON.serverRelativeUrl;
                const customUrl = imageJSON &&
                    itemSiteUrl +
                        "/Lists/SiteAssets/Attachments/" +
                        item.Id +
                        "/" +
                        (imageJSON === null || imageJSON === void 0 ? void 0 : imageJSON.fileName);
                const customPhoto = (_a = decodeURI(relativeImage)) !== null && _a !== void 0 ? _a : customUrl;
                const bannerUrl = `https://media.akamai.odsp.cdn.office.net/southindia1-mediap.svc.ms/transform/thumbnail?provider=url&inputFormat=png&docid=https://media.akamai.odsp.cdn.office.net/${window.location.host}/_layouts/15/images/sitepagethumbnail.png&w=200`;
                const lst = {
                    Title: item.Title || ((_b = item.FileRef) === null || _b === void 0 ? void 0 : _b.split("/SitePages/")[1]),
                    date: (0, moment_1.default)(item.Created).format("MMMM DD, yyyy"),
                    Created: (0, moment_1.default)(item.Created).format(),
                    Author: item.Author,
                    Department: item.Department || "",
                    ShowNewsinHome: item.ShowNewsinHome,
                    AuthorByLine: item.Author ? item.Author : "",
                    Image: customPhoto &&
                        customPhoto !== undefined &&
                        customPhoto !== "undefined"
                        ? customPhoto
                        : ((_d = (_c = item.BannerImageUrl) === null || _c === void 0 ? void 0 : _c.Url) !== null && _d !== void 0 ? _d : bannerUrl),
                    Description: item.Description,
                    Link: item.FileRef || "",
                };
                return lst;
            });
        });
    }
    getNewsPostWithNoDepartment(sites_1) {
        return tslib_1.__awaiter(this, arguments, void 0, function* (sites, top = 200, skip = 0) {
            const siteUrl = `${sites[0].url}`;
            const subweb = (0, sp_1.spfi)(siteUrl).using((0, sp_1.SPFx)(this._webPartContext));
            const filterNews = "PromotedState eq 2 and (Department eq 'All')";
            const list = subweb.web.lists.getByTitle("Site Pages");
            const getitems = yield list.items
                .filter(filterNews)
                .select("*", "Title", "Department", "ShowNewsinHome", "Modified", "BannerImageUrl", "Description", "FileRef", "FileDirRef", "Author/ID", "Author/Title", "Author/EMail")
                .expand("Author")
                .orderBy("Modified", false)
                .skip(skip)
                .top(top)();
            return getitems.map((item) => {
                var _a, _b, _c, _d;
                const itemSiteUrl = item._originSiteUrl;
                const imageJSON = item.Image && JSON.parse(item.Image);
                const relativeImage = imageJSON === null || imageJSON === void 0 ? void 0 : imageJSON.serverRelativeUrl;
                const customUrl = imageJSON &&
                    itemSiteUrl +
                        "/Lists/SiteAssets/Attachments/" +
                        item.Id +
                        "/" +
                        (imageJSON === null || imageJSON === void 0 ? void 0 : imageJSON.fileName);
                const customPhoto = (_a = decodeURI(relativeImage)) !== null && _a !== void 0 ? _a : customUrl;
                const bannerUrl = `https://media.akamai.odsp.cdn.office.net/southindia1-mediap.svc.ms/transform/thumbnail?provider=url&inputFormat=png&docid=https://media.akamai.odsp.cdn.office.net/${window.location.host}/_layouts/15/images/sitepagethumbnail.png&w=200`;
                const lst = {
                    Title: item.Title || ((_b = item.FileRef) === null || _b === void 0 ? void 0 : _b.split("/SitePages/")[1]),
                    date: (0, moment_1.default)(item.Created).format("MMMM DD, yyyy"),
                    Created: (0, moment_1.default)(item.Created).format(),
                    Author: item.Author,
                    Department: item.Department || "",
                    ShowNewsinHome: item.ShowNewsinHome,
                    AuthorByLine: item.Author ? item.Author : "",
                    Image: customPhoto &&
                        customPhoto !== undefined &&
                        customPhoto !== "undefined"
                        ? customPhoto
                        : ((_d = (_c = item.BannerImageUrl) === null || _c === void 0 ? void 0 : _c.Url) !== null && _d !== void 0 ? _d : bannerUrl),
                    Description: item.Description,
                    Link: item.FileRef || "",
                };
                return lst;
            });
        });
    }
    createNewsPost(data, sites, sitetitle) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            console.log(data);
            const siteUrl = `${sites[0].url}`;
            const subweb = (0, sp_1.spfi)(siteUrl).using((0, sp_1.SPFx)(this._webPartContext));
            const list = subweb.web.lists.getByTitle("Site Pages");
            const page3 = yield subweb.web.addClientsidePage(data.title, data.title, "Article", clientside_pages_1.PromotedState.PromoteOnPublish);
            const graph = (0, graph_1.graphfi)().using((0, graph_1.SPFx)(this._webPartContext));
            const groups = yield graph.groups();
            // you must publish the new page, after which the page will immediately be promoted to a news article
            // await page3.save();
            const item = yield subweb.web
                .getFileByServerRelativePath(`/sites/${sitetitle}/SitePages/${data.title.replace(/\s/g, "-")}.aspx`)
                .getItem();
            const gitem = yield item.select("Id", "Title")();
            const updateitem = yield list.items.getById(gitem.Id).update({
                Department: data.departments,
                // ShowNewsinHome: data.showInHome,
            });
            console.log(data.departments);
            if (data.departments.length > 0 &&
                data.departments.includes("All") === false) {
                try {
                    const context = yield this._webPartContext.spHttpClient.post(`${siteUrl}/_api/web/lists/getByTitle('Site Pages')/Items/getById(${gitem.Id})/breakroleinheritance(copyRoleAssignments=false,clearSubscopes=true)`, sp_http_1.SPHttpClient.configurations.v1, {
                        headers: {
                            Accept: "application/json;odata=nometadata",
                            "Content-Type": "application/json;odata=nometadata",
                            "odata-version": "",
                        },
                    });
                    if (!context.ok) {
                        console.error("Failed to break role inheritance:", yield context.text());
                    }
                    else {
                        // console.log("Role inheritance broken successfully");
                    }
                }
                catch (error) {
                    console.error("Error breaking role inheritance:", error);
                }
                const sitePagelist = subweb.web.lists.getByTitle("Site Pages");
                // we can use this 'list' variable to run more queries on the list:
                const sitePagesListID = yield sitePagelist.select("Id")();
                for (const departmentName of data.departments) {
                    const groupID = groups.find((g) => g.displayName === departmentName);
                    const peoplePickerInput = JSON.stringify([
                        {
                            Key: `c:0o.c|federateddirectoryclaimprovider|${groupID.id}`,
                            DisplayText: `${departmentName} Members`,
                            IsResolved: true,
                            Description: departmentName,
                            EntityType: "SecGroup",
                            EntityData: {},
                            MultipleMatches: [],
                            ProviderName: `FederatedDirectoryClaimProvider`,
                            ProviderDisplayName: `Federated Directory`,
                        },
                    ]);
                    const sharePayload = {
                        peoplePickerInput: peoplePickerInput,
                        roleValue: "role:1073741827",
                        sendEmail: false,
                        emailBody: null,
                        includeAnonymousLinkInEmail: false,
                        propagateAcl: true,
                        useSimplifiedRoles: true,
                    };
                    const shareResponse = yield this._webPartContext.spHttpClient.post(`${siteUrl}/_api/web/Lists(@a1)/GetItemById(@a2)/ShareObject?@a1='${sitePagesListID.Id}'&@a2='${gitem.Id}'`, sp_http_1.SPHttpClient.configurations.v1, {
                        headers: {
                            Accept: "application/json;odata=nometadata",
                            "Content-Type": "application/json;odata=nometadata",
                            "odata-version": "",
                        },
                        body: JSON.stringify(sharePayload),
                    });
                    if (!shareResponse.ok) {
                        console.error(`Failed to share with user ${departmentName}:`, yield shareResponse.text());
                    }
                    else {
                        // console.log(`Successfully shared with user ${user.text}`);
                    }
                }
            }
            return `/sites/${sitetitle}/SitePages/${data.title.replace(/\s/g, "-")}.aspx?Mode=Edit`;
        });
    }
}
exports.default = SharepointServiceProvider;
//# sourceMappingURL=SharepointServiceProvider.js.map