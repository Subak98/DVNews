"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSP = void 0;
// import pnp, pnp logging system, and any other selective imports needed
const sp_1 = require("@pnp/sp");
const logging_1 = require("@pnp/logging");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/fields");
require("@pnp/sp/clientside-pages");
require("@pnp/sp/security");
let _sp = new sp_1.SPFI();
const getSP = (context) => {
    if (context !== null && context !== undefined) {
        // Configure logging with ConsoleListener
        // Logger.subscribe(new ConsoleListener());
        logging_1.Logger.activeLogLevel = logging_1.LogLevel.Warning;
        _sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(context));
    }
    return _sp;
};
exports.getSP = getSP;
//# sourceMappingURL=pnpjsConfig.js.map