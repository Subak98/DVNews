"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const React = tslib_1.__importStar(require("react"));
const DvNews_module_scss_1 = tslib_1.__importDefault(require("./DvNews.module.scss"));
const moment_1 = tslib_1.__importDefault(require("moment"));
const react_1 = require("swiper/react");
const modules_1 = require("swiper/modules");
require("swiper/css");
require("swiper/css/navigation");
require("swiper/css/pagination");
const Dropdown_1 = require("@fluentui/react/lib/Dropdown");
const react_2 = require("@fluentui/react");
require("@pnp/graph/groups");
require("@pnp/graph/members");
const DvNews = (props) => {
    var _a, _b;
    const [newsItems, setNewsItems] = React.useState([]);
    const [deptOptions, setDeptOptions] = React.useState([]);
    const [redirecturl, setRedirectUrl] = React.useState("");
    const [isAddDialogOpen, setIsAddDialogOpen] = React.useState(false);
    const [isLoadingNews, setIsLoadingNews] = React.useState(false);
    const [isCreatingItem, setIsCreatingItem] = React.useState(false);
    const [isLoadingMoreNews, setIsLoadingMoreNews] = React.useState(false);
    const [createdItemSuccess, setCreatedItemSuccess] = React.useState(false);
    const [newTitle, setNewTitle] = React.useState("");
    const [selectedDepartments, setSelectedDepartments] = React.useState([]);
    const [selectedSiteTypes, setSelectedSiteTypes] = React.useState([]);
    const [showInHome, setShowInHome] = React.useState(false);
    const [newTitleError, setNewTitleError] = React.useState("");
    const [newTitleWarning, setNewTitleWarning] = React.useState("Avoid special characters like #^*|\"':<>/?.");
    const [selectedNewsItem, setSelectedNewsItem] = React.useState(null);
    const [isNewsDetailsOpen, setIsNewsDetailsOpen] = React.useState(false);
    const fetchNewsPost = () => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
        const firstBatchSize = 5;
        setIsLoadingNews(true);
        try {
            const firstBatch = yield props.provider.getNewsPost(props.searchSites, firstBatchSize, 0);
            console.log("First batch:", firstBatch);
            setNewsItems(firstBatch);
            setIsLoadingMoreNews(true);
            try {
                const remainingNews = yield props.provider.getNewsPost(props.searchSites, 200, firstBatchSize);
                console.log("Remaining batch:", remainingNews);
                if (remainingNews.length > 0) {
                    setNewsItems((prev) => [
                        ...prev,
                        ...remainingNews.filter((item) => !prev.some((existing) => existing.Link === item.Link)),
                    ]);
                }
            }
            catch (error) {
                console.error("Error fetching remaining news posts:", error);
            }
            finally {
                setIsLoadingMoreNews(false);
            }
        }
        catch (error) {
            console.error("Error fetching news posts:", error);
            setNewsItems([]);
        }
        finally {
            setIsLoadingNews(false);
        }
    });
    const fetchHomeNewsPost = () => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
        setIsLoadingNews(true);
        const noDepartmentFetch = yield props.provider
            .getNewsPostWithNoDepartment(props.searchSites, 200, 0)
            .then((res) => {
            console.log(res);
            setNewsItems(res);
        })
            .catch((err) => {
            console.log("Error");
        })
            .finally(() => {
            setIsLoadingNews(false);
        });
    });
    React.useEffect(() => {
        if (props.layout == "Home") {
            fetchHomeNewsPost().catch((error) => {
                console.error("Error fetching home news posts:", error);
            });
        }
        else {
            fetchNewsPost().catch((error) => {
                console.error("Error fetching news posts:", error);
            });
        }
    }, []);
    const fetchDepartmentsOption = () => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
        const news = yield props.provider
            .getDepartmentFieldOptions(props.searchSites)
            .then((res) => {
            setDeptOptions(res.map((dept) => ({
                key: dept,
                text: dept,
                value: dept,
            })));
        });
    });
    React.useEffect(() => {
        fetchDepartmentsOption().catch((error) => {
            console.error("Error fetching departments:", error);
        });
    }, []);
    // const fetchGroups = async () => {
    //   const graph = graphfi().using(graphSPFx(props.context));
    //   const groups = await graph.groups();
    //   const targetGroup: any = groups.find((g) => g.displayName === "DV Legal");
    //   if (targetGroup) {
    //     const gmembers = await graph.groups.getById(targetGroup.id).members();
    //     console.log(gmembers);
    //     const gowners = await graph.groups.getById(targetGroup.id).owners();
    //   }
    //   const members = await graph.groups
    //     .getById("4e52aa91-8ace-43c6-b006-e328fb1f0386")
    //     .owners();
    //   console.log(members);
    // };
    // React.useEffect(() => {
    //   fetchGroups().catch((error) => {
    //     console.error("Error fetching groups:", error);
    //   });
    // }, []);
    const responsive = React.useMemo(() => {
        const perPage = 4;
        return {
            // Extra small phones
            0: {
                slidesPerView: 1,
                spaceBetween: 10,
            },
            // Small phones / portrait
            480: {
                slidesPerView: Math.min(perPage, 2),
                spaceBetween: 15,
            },
            // Tablets
            768: {
                slidesPerView: Math.min(perPage, 3),
                spaceBetween: 20,
            },
            // Small desktops / laptops
            1024: {
                slidesPerView: Math.min(perPage, 4),
                spaceBetween: 20,
            },
            // Large desktops
            1440: {
                slidesPerView: perPage,
                spaceBetween: 20,
            },
        };
    }, [4]);
    const validateTitle = (value) => {
        const titleValue = value.trim();
        if (!titleValue) {
            setNewTitleError("Title is required.");
            return false;
        }
        const invalidTitlePattern = /[#^*|"'<>/:?\\]/;
        if (invalidTitlePattern.test(titleValue)) {
            setNewTitleError("Title cannot contain special characters like #^*|\"':<>/?.");
            return false;
        }
        setNewTitleError("");
        return true;
    };
    const handleCreateItem = () => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
        const titleValue = newTitle.trim();
        if (!validateTitle(titleValue)) {
            return;
        }
        const createData = {
            title: titleValue,
            departments: selectedDepartments,
            showInHome,
        };
        setIsCreatingItem(true);
        // setIsAddDialogOpen(false);
        try {
            yield props.provider
                .createNewsPost(createData, props.searchSites, props.sitetitle)
                .then((res) => {
                console.log(res);
                setRedirectUrl(res);
                setCreatedItemSuccess(true);
                setIsCreatingItem(false);
            });
        }
        catch (error) {
            console.error("Error creating news post:", error);
            setIsCreatingItem(false);
        }
    });
    const handleRedirect = () => {
        window.location.href = redirecturl;
    };
    const openAddDialog = () => {
        setNewTitle("");
        setSelectedDepartments([]);
        setSelectedSiteTypes([]);
        setShowInHome(false);
        setNewTitleError("");
        setCreatedItemSuccess(false);
        setIsAddDialogOpen(true);
    };
    const isAdminUser = props.adminUsers
        ? props.adminUsers.some((user) => { var _a, _b; return ((_a = user.email) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === ((_b = props.userEmail) === null || _b === void 0 ? void 0 : _b.toLowerCase()); })
        : [];
    const formatDetailDate = (value) => {
        if (!value)
            return "N/A";
        const parsedDate = (0, moment_1.default)(value);
        return parsedDate.isValid() ? parsedDate.format("DD MMMM YYYY") : "N/A";
    };
    const getDetailValue = (value) => {
        if (!value)
            return "N/A";
        if (Array.isArray(value)) {
            return value.filter(Boolean).join(", ");
        }
        if (typeof value === "object") {
            return value.Title || value.name || value.displayName || "N/A";
        }
        return String(value);
    };
    const getDepartmentValue = (item) => {
        const departmentValue = (item === null || item === void 0 ? void 0 : item.Departments) ||
            (item === null || item === void 0 ? void 0 : item.Department) ||
            (item === null || item === void 0 ? void 0 : item.DepartmentName) ||
            (item === null || item === void 0 ? void 0 : item.DepartmentNames) ||
            (item === null || item === void 0 ? void 0 : item.DepartmentValues);
        return getDetailValue(departmentValue);
    };
    const openNewsDetails = (item) => {
        setSelectedNewsItem(item);
        setIsNewsDetailsOpen(true);
    };
    const closeNewsDetails = () => {
        setSelectedNewsItem(null);
        setIsNewsDetailsOpen(false);
    };
    const handleDepartmentChange = (_event, option) => {
        if (!option) {
            return;
        }
        const optionKey = option.key;
        if (optionKey === "All") {
            setSelectedDepartments((prev) => (prev.includes("All") ? [] : ["All"]));
            return;
        }
        setSelectedDepartments((prev) => {
            if (prev.includes("All")) {
                return prev;
            }
            return prev.includes(optionKey)
                ? prev.filter((key) => key !== optionKey)
                : [...prev, optionKey];
        });
    };
    return (React.createElement(React.Fragment, null,
        React.createElement("div", { className: `${DvNews_module_scss_1.default.featuredNews} ` },
            React.createElement("div", { className: `${DvNews_module_scss_1.default.contentBox}`, style: {
                    borderTopColor: "black",
                } },
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between" }, className: DvNews_module_scss_1.default.contentBox__heading },
                    React.createElement("div", { className: `${DvNews_module_scss_1.default.contentBox__heading}` },
                        React.createElement("span", { className: DvNews_module_scss_1.default.boxWebPartTitle }, props.title || "News")),
                    isAdminUser && (React.createElement("div", { className: DvNews_module_scss_1.default.addForm },
                        React.createElement("button", { type: "button", className: DvNews_module_scss_1.default.addFormBtn, onClick: openAddDialog }, "Add")))),
                isAddDialogOpen && (React.createElement("div", { className: DvNews_module_scss_1.default.modalOverlay, onClick: () => setIsAddDialogOpen(false) },
                    React.createElement("div", { className: DvNews_module_scss_1.default.modalContent, onClick: (event) => event.stopPropagation() },
                        React.createElement("div", { className: DvNews_module_scss_1.default.modalHeader },
                            React.createElement("div", null,
                                React.createElement("div", { className: DvNews_module_scss_1.default.modalTitle }, "Add News Item")),
                            React.createElement("button", { type: "button", className: DvNews_module_scss_1.default.modalClose, onClick: () => setIsAddDialogOpen(false), "aria-label": "Close" }, "\u00D7")),
                        React.createElement("div", { className: DvNews_module_scss_1.default.modalBody },
                            React.createElement("div", { className: DvNews_module_scss_1.default.formRow },
                                React.createElement(react_2.TextField, { label: "Title", value: newTitle, onChange: (event) => {
                                        setNewTitle(event.target.value);
                                        if (newTitleError) {
                                            setNewTitleError("");
                                        }
                                    }, placeholder: "Enter title", required: true, disabled: isCreatingItem, description: newTitleWarning, errorMessage: newTitleError })),
                            React.createElement("div", { className: DvNews_module_scss_1.default.formRow },
                                React.createElement("div", { className: DvNews_module_scss_1.default.inputLabelRow },
                                    React.createElement("label", { className: DvNews_module_scss_1.default.inputLabel }, "Departments"),
                                    React.createElement("button", { type: "button", className: DvNews_module_scss_1.default.clearBtn, onClick: () => setSelectedDepartments([]) }, "Clear")),
                                React.createElement(Dropdown_1.Dropdown, { placeholder: "Select Departments", multiSelect: true, disabled: isCreatingItem, selectedKeys: selectedDepartments, onChange: handleDepartmentChange, options: deptOptions.map((dept) => (Object.assign(Object.assign({}, dept), { disabled: selectedDepartments.includes("All") &&
                                            dept.key !== "All" }))) })),
                            React.createElement("div", { className: DvNews_module_scss_1.default.toggleRow })),
                        React.createElement("div", { className: DvNews_module_scss_1.default.buttonGroup },
                            React.createElement("button", { type: "button", className: DvNews_module_scss_1.default.createBtn, onClick: handleCreateItem, disabled: isCreatingItem || !newTitle.trim() }, isCreatingItem ? "Creating..." : "Create"))))),
                createdItemSuccess && (React.createElement(React.Fragment, null,
                    React.createElement("div", { className: DvNews_module_scss_1.default.modalOverlay, onClick: () => setCreatedItemSuccess(false) },
                        React.createElement("div", { className: DvNews_module_scss_1.default.successModalContent, onClick: (event) => event.stopPropagation() },
                            React.createElement("div", { className: DvNews_module_scss_1.default.successIcon }, "\u2713"),
                            React.createElement("div", { className: DvNews_module_scss_1.default.successTitle }, "Item Created Successfully"),
                            React.createElement("div", { className: DvNews_module_scss_1.default.successMessage }, "Your news item has been created and will be available shortly."),
                            React.createElement("button", { type: "button", className: DvNews_module_scss_1.default.redirectBtn, onClick: handleRedirect }, "Go to News Page"))))),
                isNewsDetailsOpen && selectedNewsItem && (React.createElement("div", { className: DvNews_module_scss_1.default.modalOverlay, onClick: closeNewsDetails },
                    React.createElement("div", { className: DvNews_module_scss_1.default.newsDetailsModalContent, onClick: (event) => event.stopPropagation() },
                        React.createElement("div", { className: DvNews_module_scss_1.default.modalHeader },
                            React.createElement("div", null,
                                React.createElement("div", { className: DvNews_module_scss_1.default.modalTitle }, "News Details")),
                            React.createElement("button", { type: "button", className: DvNews_module_scss_1.default.modalClose, onClick: closeNewsDetails, "aria-label": "Close" }, "\u00D7")),
                        React.createElement("div", { className: DvNews_module_scss_1.default.modalBody },
                            React.createElement("div", { className: DvNews_module_scss_1.default.detailRow },
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailLabel }, "Title: "),
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailValue }, getDetailValue(selectedNewsItem.Title))),
                            React.createElement("div", { className: DvNews_module_scss_1.default.detailRow },
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailLabel }, "Modified Date: "),
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailValue }, formatDetailDate(selectedNewsItem.Modified ||
                                    selectedNewsItem.modified ||
                                    selectedNewsItem.LastModifiedTime ||
                                    selectedNewsItem.date))),
                            React.createElement("div", { className: DvNews_module_scss_1.default.detailRow },
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailLabel },
                                    "Modified Person:",
                                    " "),
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailValue }, getDetailValue(((_a = selectedNewsItem.AuthorByLine) === null || _a === void 0 ? void 0 : _a.Title) ||
                                    ((_b = selectedNewsItem.AuthorByLine) === null || _b === void 0 ? void 0 : _b.EMail) ||
                                    selectedNewsItem.ModifiedBy ||
                                    selectedNewsItem.Author ||
                                    selectedNewsItem.AuthorByLine))),
                            React.createElement("div", { className: DvNews_module_scss_1.default.detailRow },
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailLabel }, "Departments: "),
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailValue },
                                    " ",
                                    getDepartmentValue(selectedNewsItem))),
                            React.createElement("div", { className: DvNews_module_scss_1.default.detailRow },
                                React.createElement("span", { className: DvNews_module_scss_1.default.detailLabel }, "Description: "),
                                React.createElement("div", { className: DvNews_module_scss_1.default.detailDescription, dangerouslySetInnerHTML: {
                                        __html: selectedNewsItem.Description ||
                                            "No description available.",
                                    } })))))),
                React.createElement("div", null, isLoadingNews ? (React.createElement("div", { className: DvNews_module_scss_1.default.loadingContainer },
                    React.createElement(react_2.Spinner, { label: "Loading news...", size: react_2.SpinnerSize.large }))) : newsItems.length === 0 ? (React.createElement("div", { className: DvNews_module_scss_1.default.emptyState }, "No results found.")) : (React.createElement(React.Fragment, null,
                    React.createElement(react_1.Swiper
                    // key={`${props.itemsToShowPerPage}-${props.item.length}`}
                    , { 
                        // key={`${props.itemsToShowPerPage}-${props.item.length}`}
                        modules: [modules_1.Navigation, modules_1.Pagination], navigation: true, 
                        // Base fallback; overridden by breakpoints for all widths >= 0
                        slidesPerView: 1, breakpoints: responsive, className: "featuredNews" }, newsItems.length > 0 &&
                        newsItems.map((item, index) => {
                            const image = item.Link.includes("Pillars/SitePages")
                                ? `${props.context.pageContext.site.absoluteUrl}/_layouts/15/userphoto.aspx?size=L&username=${encodeURIComponent(item.AuthorByLine && item.AuthorByLine.EMail
                                    ? item.AuthorByLine.EMail
                                    : "")}`
                                : item.Image;
                            return (React.createElement(react_1.SwiperSlide, { key: index },
                                React.createElement("div", { className: DvNews_module_scss_1.default.filmstripView_Container },
                                    React.createElement("div", null,
                                        React.createElement("img", { src: image, height: 215, alt: item.Title, width: "100%" }),
                                        React.createElement("div", { className: DvNews_module_scss_1.default.titleDateContainer },
                                            React.createElement("div", { className: DvNews_module_scss_1.default.filmstripView_datetime }, (0, moment_1.default)(item.date).format("DD MMMM YYYY")),
                                            React.createElement("button", { type: "button", className: DvNews_module_scss_1.default.filmstripView_titleButton, onClick: () => openNewsDetails(item) }, item.Title),
                                            React.createElement("div", { className: DvNews_module_scss_1.default.DescriptionNews, title: item.Description, dangerouslySetInnerHTML: {
                                                    __html: item.Description,
                                                } }),
                                            React.createElement("a", { href: item.Link, target: "_blank", "data-interception": "propagate", className: DvNews_module_scss_1.default.learnMoreCont },
                                                React.createElement("button", { onClick: () => window.open(item.Link, "_blank"), className: DvNews_module_scss_1.default.learnMore }, "Read More")))))));
                        })),
                    isLoadingMoreNews && (React.createElement("div", { className: DvNews_module_scss_1.default.loadingContainer },
                        React.createElement(react_2.Spinner, { label: "Loading more news...", size: react_2.SpinnerSize.small }))))))))));
};
exports.default = DvNews;
//# sourceMappingURL=DvNews.js.map