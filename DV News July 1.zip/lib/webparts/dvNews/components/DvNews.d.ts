import * as React from "react";
import type { IDvNewsProps } from "./IDvNewsProps";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "@pnp/graph/groups";
import "@pnp/graph/members";
declare const DvNews: React.FC<IDvNewsProps>;
export default DvNews;
//# sourceMappingURL=DvNews.d.ts.map