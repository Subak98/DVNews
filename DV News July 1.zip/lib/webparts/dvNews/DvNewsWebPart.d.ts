import { Version } from "@microsoft/sp-core-library";
import { type IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { IReadonlyTheme } from "@microsoft/sp-component-base";
import { IPropertyFieldSite } from "@pnp/spfx-property-controls/lib/PropertyFieldSitePicker";
import { IPropertyFieldGroupOrPerson } from "@pnp/spfx-property-controls/lib/PropertyFieldPeoplePicker";
export interface IDvNewsWebPartProps {
    title: string;
    searchSites: IPropertyFieldSite[];
    adminUsers: IPropertyFieldGroupOrPerson[];
    layout: string;
    sitetitle: string;
}
export default class DvNewsWebPart extends BaseClientSideWebPart<IDvNewsWebPartProps> {
    private _serviceProvider;
    private _isDarkTheme;
    private _environmentMessage;
    private graph;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=DvNewsWebPart.d.ts.map