import { IServiceProvider } from "./IServiceProvider";
import { BaseWebPartContext } from "@microsoft/sp-webpart-base";
import { SPFI } from "@pnp/sp";
import "@pnp/graph/groups";
import "@pnp/graph/members";
import { IFeaturedNewsList } from "./IObject";
import { IPropertyFieldSite } from "@pnp/spfx-property-controls";
export default class SharepointServiceProvider implements IServiceProvider {
    _webPartContext: BaseWebPartContext;
    _webAbsoluteUrl: string;
    sp: SPFI;
    private _cachedGraphGroups;
    constructor(_context: BaseWebPartContext);
    getDepartmentFieldOptions(sites: IPropertyFieldSite[]): Promise<any[]>;
    getNewsPost(sites: IPropertyFieldSite[], top?: number, skip?: number): Promise<IFeaturedNewsList[]>;
    getNewsPostWithNoDepartment(sites: IPropertyFieldSite[], top?: number, skip?: number): Promise<IFeaturedNewsList[]>;
    createNewsPost(data: any, sites: IPropertyFieldSite[], sitetitle: string): Promise<any>;
}
//# sourceMappingURL=SharepointServiceProvider.d.ts.map