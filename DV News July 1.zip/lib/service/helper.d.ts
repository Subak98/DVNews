export declare function timeAgo(input: Date | string | number): string;
//# sourceMappingURL=helper.d.ts.map